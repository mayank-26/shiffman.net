Download the Twitter4j library from here:

http://www.twitter4j.org

Then place the library JAR file into this folder...